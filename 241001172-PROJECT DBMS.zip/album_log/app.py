from flask import Flask, render_template, request, redirect, session
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
# IMPORTANT: Use a strong, unique secret key!
app.secret_key = "your_strong_albumlog_secret_key"

# --- Database Connection ---
try:
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="qwert", # Use your actual database password
        database="albumlog" # CHANGED: Database name updated to 'albumlog'
    )
    cursor = db.cursor(dictionary=True)
except mysql.connector.Error as err:
    print(f"Error connecting to MySQL: {err}")
    # Consider better error handling for production, but this is fine for local dev.

@app.route('/')
def home():
    """Redirects authenticated users to the dashboard, others to login."""
    if 'user_id' in session:
        return redirect('/dashboard')
    return redirect('/login')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Handles user registration."""
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        
        # CHANGED: Query updated to use 'review_users'
        cursor.execute("SELECT id FROM review_users WHERE username=%s", (username,))
        if cursor.fetchone():
            error = "Username already exists. Please choose another."
            return render_template('register.html', error=error)
            
        try:
            # CHANGED: Query updated to use 'review_users'
            cursor.execute("INSERT INTO review_users (username, password) VALUES (%s, %s)", (username, password))
            db.commit()
            return redirect('/login')
        except mysql.connector.Error as e:
            error = f"Database error: {e}"
            return render_template('register.html', error=error)

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Handles user login."""
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # CHANGED: Query updated to use 'review_users'
        cursor.execute("SELECT id, username, password FROM review_users WHERE username=%s", (username,))
        user = cursor.fetchone()
        
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect('/dashboard')
        
        error = "Invalid username or password"
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    """Clears the session and redirects to login."""
    session.clear()
    return redirect('/login')

@app.route('/dashboard')
def dashboard():
    """Displays the user's list of album reviews."""
    if 'user_id' not in session:
        return redirect('/login')
    
    # CHANGED: Query updated to use 'album_reviews'
    # Select all album reviews, ordered by newest first
    cursor.execute("SELECT * FROM album_reviews WHERE user_id=%s ORDER BY id DESC", (session['user_id'],))
    albums = cursor.fetchall()
    
    return render_template('dashboard.html', albums=albums, username=session['username'])

@app.route('/add', methods=['GET', 'POST'])
def add_album():
    """Handles adding a new album review with rating."""
    if 'user_id' not in session:
        return redirect('/login')
    
    if request.method == 'POST':
        album_name = request.form['album_name']
        artist_name = request.form['artist_name']
        review = request.form['review']
        rating = request.form['rating'] 
        # ADDED: Retrieve the image URL from the hidden field
        image_url = request.form.get('image_url', None)
        
        try:
            # UPDATED: Query now includes 'image_url' column
            cursor.execute("INSERT INTO album_reviews (user_id, album_name, artist_name, review, rating, image_url) VALUES (%s, %s, %s, %s, %s, %s)",
                           (session['user_id'], album_name, artist_name, review, rating, image_url))
            db.commit()
            return redirect('/dashboard')
        except mysql.connector.Error as e:
            # Simple error message if insertion fails
            print(f"Error adding album: {e}")
            return render_template('add_review.html', error="Failed to add review. Check your input.")

    return render_template('add_review.html')

if __name__ == "__main__":
    app.run(debug=True)
